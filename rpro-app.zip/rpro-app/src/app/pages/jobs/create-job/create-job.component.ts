import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NavigationService } from '../../../providers/navigation.service';

@Component({
  selector: 'app-create-job',
  templateUrl: './create-job.component.html',
  styleUrls: ['./create-job.component.css']
})
export class CreateJobComponent implements OnInit {

  constructor(private router: Router, private navSrvc:NavigationService) { }

  ngOnInit() {
    this.navSrvc.updatePageToolkitHeader('<span>Create New Job</span>');
  }

  redirectListJobs(){
    this.router.navigate(['list-jobs']);
  }


}
