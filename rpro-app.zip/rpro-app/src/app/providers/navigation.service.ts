import { Injectable } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  pageToolkitHeader:any = null;
  constructor(private sanitizer: DomSanitizer) { }

  updatePageToolkitHeader(content: string){
    this.pageToolkitHeader =  this.sanitizer.bypassSecurityTrustHtml('Recruit Pro - ' + content);
  }
}
