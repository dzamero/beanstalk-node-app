import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CreateJobComponent } from '../jobs/create-job/create-job.component';

@Component({
  selector: 'login-module',
  templateUrl: './login-module.component.html',
  styleUrls: ['./login-module.component.css']
})
export class LoginModuleComponent {
  constructor(private router: Router) { }

  cards = [
    { title: 'Login Form', cols: 3, rows: 1 }
  ];

  login(){
    this.router.navigate(['list-jobs']);
  }
}
