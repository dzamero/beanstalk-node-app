import { Component, OnInit } from '@angular/core';
import { MockJobService } from '../../../providers/mock/mock-job.service';
import { ActivatedRoute } from '@angular/router';
import { Job } from '../../../model/job';

@Component({
  selector: 'app-view-job',
  templateUrl: './view-job.component.html',
  styleUrls: ['./view-job.component.css']
})
export class ViewJobComponent implements OnInit {
  job:any;

  constructor(private mockJobSrvc: MockJobService, private route: ActivatedRoute) {
  }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('job_id');
    this.job = this.mockJobSrvc.query({ id: id })
    
  }

}
