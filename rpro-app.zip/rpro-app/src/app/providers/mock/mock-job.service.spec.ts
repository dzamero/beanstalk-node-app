import { TestBed, inject } from '@angular/core/testing';

import { MockJobService } from './mock-job.service';

describe('MockJobService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MockJobService]
    });
  });

  it('should be created', inject([MockJobService], (service: MockJobService) => {
    expect(service).toBeTruthy();
  }));
});
