import { Component, OnInit } from '@angular/core';
import { MockJobService } from '../../../providers/mock/mock-job.service';
import { Job } from '../../../model/job';
import { Router } from '@angular/router';
import { NavigationService } from '../../../providers/navigation.service';

@Component({
  selector: 'app-list-jobs',
  templateUrl: './list-jobs.component.html',
  styleUrls: ['./list-jobs.component.css']
})
export class ListJobsComponent implements OnInit {
  jobs: Job[] = [];

  constructor(private navSrvc:NavigationService,private router: Router , private mockJobSrvc: MockJobService) {
    this.jobs = mockJobSrvc.jobs;
  }

  search($event) {
    console.log($event.target.value);
    this.jobs = this.mockJobSrvc.query({description:$event.target.value, title:$event.target.value});
  }

  redirectCreateJob(){
    this.router.navigate(['create-job']);
  }

  redirectViewJob(job){
    
    this.router.navigate(['view-job',{job_id:job.id}]);
  }
  

  ngOnInit() {
    this.navSrvc.updatePageToolkitHeader('<span>Jobs</span>');
  }

}
