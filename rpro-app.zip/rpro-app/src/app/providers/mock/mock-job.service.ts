import { Injectable } from '@angular/core';
import { Job } from '../../model/job';
import { Skill } from '../../model/skill';

@Injectable({
  providedIn: 'root'
})
export class MockJobService {
  jobs: Job[] = [];

  constructor() {
    let skills=["XML","JDBC","JMS","NodeJS","Python","Ruby","Angular","React","IONIC"];

    let jobs = [
      {
        "id": "001",
        "title":"Java Developer",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"1"
      },
      {
        "id": "002",
        "title":"ETL Developer2",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"2"
      },
      {
        "id": "003",
        "title":"Mainframe Developer3",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"3"
      },
      {
        "id": "004",
        "title":"Java Developer4",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"4"
      },
      {
        "id": "005",
        "title":"Java Developer5",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"5"
      },
      {
        "id": "006",
        "title":"Java Developer6",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"6"
      },
      {
        "id": "007",
        "title":"Java Developer7",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"7"
      },
      {
        "id": "008",
        "title":"Java Developer8",
        "description": "A Java developer is responsible for many duties throughout the development lifecycle of applications, from concept and design right through to testing. Here are some other responsibilities they may have: Design, implement and maintain java application phases. ... Develop, test, implement and maintain application software.",
        "skills":skills,
        "openings":"8"
      },
    ];

    for (let job of jobs) {
      this.jobs.push(new Job(job));
    }
  }


   query(params?: any) {
    if (!params) {
      return this.jobs;
    }

    return this.jobs.filter((job) => {
      for (let key in params) {
        let field = job[key];
        if (typeof field == 'string' && field.toLowerCase().indexOf(params[key].toLowerCase()) >= 0) {
          return job;
        } else if (field == params[key]) {
          return job;
        }
      }
      return null;
    });
  }

}




