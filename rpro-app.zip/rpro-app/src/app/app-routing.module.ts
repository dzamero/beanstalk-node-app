import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginModuleComponent } from './pages/login-module/login-module.component';
import { CreateJobComponent } from './pages/jobs/create-job/create-job.component';
import { ViewJobComponent } from './pages/jobs/view-job/view-job.component';
import { ListJobsComponent } from './pages/jobs/list-jobs/list-jobs.component';
import { UpdateJobComponent } from './pages/jobs/update-job/update-job.component';

const appRoutes: Routes = [
   {path: '', redirectTo: 'login', pathMatch: 'full'},
   {path: 'login', component: LoginModuleComponent},
   { path: 'create-job', component: CreateJobComponent },
   { path: 'view-job', component: ViewJobComponent },
   { path: 'list-jobs', component: ListJobsComponent },
   { path: 'update-job', component: UpdateJobComponent }
];


@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
      {
        enableTracing: true

      }
    )
  ],
  exports: [
    RouterModule
  ]})
export class AppRoutingModule { }