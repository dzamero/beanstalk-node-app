import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

//Routing imports
import { AppRoutingModule } from './app-routing.module';
import { LoginModuleComponent } from './pages/login-module/login-module.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import { MatGridListModule, MatCardModule, MatMenuModule, MatIconModule, MatButtonModule,
   MatSelectModule, MatOptionModule,MatInputModule,MatTabsModule, MatToolbarModule, MatSidenavModule, MatListModule, MatBadgeModule, MatChipList, MatChip, MatChipsModule } from '@angular/material';

import { LayoutModule } from '@angular/cdk/layout';
import { CreateJobComponent } from './pages/jobs/create-job/create-job.component';
import { UpdateJobComponent } from './pages/jobs/update-job/update-job.component';
import { ViewJobComponent } from './pages/jobs/view-job/view-job.component';
import { ListJobsComponent } from './pages/jobs/list-jobs/list-jobs.component';

import {NgxPaginationModule} from 'ngx-pagination';
import { NavComponent } from './pages/nav/nav.component'

@NgModule({
  declarations: [
    AppComponent,
    LoginModuleComponent,
    CreateJobComponent,
    UpdateJobComponent,
    ViewJobComponent,
    ListJobsComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
    NgbModule.forRoot(),
    BrowserAnimationsModule,
    MatGridListModule,
    MatCardModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    AppRoutingModule,
    MatFormFieldModule,
    MatSelectModule,
    MatOptionModule,
    MatInputModule,
    MatTabsModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatListModule,
    MatBadgeModule,
    MatChipsModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
